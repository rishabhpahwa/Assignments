def gen_array(size):
	a=[[0 for x in range(size)] for y in range(size)]
	for i in range(0,size)
		for j in range(0,size)
			a[i][j]=

def SFC(n):
	a=(4)^n
	b=(4)^n
	x=[]
	y=[]
	lim=
	for i in range(0,2^n)
		if
	temp1=x.reverse()
	x.extend(temp1)
	size2=len(y)
	for index in range(len(y)-1,0,-1)
		 y.append(((2^n)+1)-y[index])
k=input("Enter the order: ")
SFC(k)

	
