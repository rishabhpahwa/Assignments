import string
import pdb
def sort_file(sherlock):
	'''This function reads the given text file and then converts the contents to lower case letters skipping any other characters found in the text. It also creates an array for the words occuring in the document and finally calls the sort function to sort the words alphabetically.'''
        a=open("sherlock.txt","r")
        lines=a.read()
	global i
	#print lines,"  ",len(lines)
	s=lines.lower()
	words=[]
        while i<len(s):
		if s[i]>='a' and s[i]<='z':
			words.append(next_word(s,i))
		i=i+1
	sort_str(words)
	print "The sorted words are:\n",words
	x=raw_input("Enter the word you wish to search among the sorted words:\n")
	n_words=words[:]
	match_found=binary_search(n_words,0,len(n_words)-1,x)
def next_word(s,q):
	'''Returns the current word as a character array to the calling routine.'''
	global i
	i=q
	stri=""
	while s[i]>='a' and s[i]<='z':
		stri+=s[i]		
		i+=1
	return stri
def sort_str(words):
	'''sorts the array of strings lexicographically.'''
	for k in range(0,len(words)-1):
		for l in range(0, len(words)-1-k):
			if words[l]>words[l+1]:
				words[l],words[l+1]=words[l+1],words[l]
def binary_search(n_words,l,r,x):
	'''Performs binary search on the sorted strings.'''
	index=(l+r)/2
	#pdb.set_trace()
	if x>n_words[index] and index>0:
		binary_search(n_words,index,r,x)
	if x<n_words[index] and index>0:
		binary_search(n_words,l,index,x)
	if x==n_words[index]:
		print "Match found at index: ",index
		return index
	elif index<0:
		print "Word is not found."
i=0
sherlock=1
sort_file(sherlock)
