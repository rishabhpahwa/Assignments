Dear ma'am,
	The codes submitted are in accordance with the desired output as mentioned in the mail. :)
The partition function defined is just the function itself in the separate code but is also used in the quicksort.py code.
The display_the_matrix code is also provided separately for simplicity. :)

Thank You,
	Rishabh Pahwa
	2013CSB1028