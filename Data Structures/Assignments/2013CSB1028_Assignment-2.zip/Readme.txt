Dear ma'am,
	The codes submitted are in accordance with the desired output as mentioned in the mail. :)

Thank You,
	Rishabh Pahwa
	2013CSB1028