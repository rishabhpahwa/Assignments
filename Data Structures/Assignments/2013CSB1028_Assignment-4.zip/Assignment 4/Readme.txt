Dear ma'am,
	The codes submitted are in accordance with the desired output as informed. :)
The heap_sort compare algorithm is performed on a general code for a "k-ary" heap, putting k=2 once and k=3 hence.

Thank You,
	Rishabh Pahwa
	2013CSB1028