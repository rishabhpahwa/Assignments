To run the code:
1) Browse to the current working directory
2) Type in the terminal-
	$ python code.py (inputFile).txt (inputQuery).txt {optional - no. of samples}

By default if number of samples is not given as input, then the number of samples is set to 2500.