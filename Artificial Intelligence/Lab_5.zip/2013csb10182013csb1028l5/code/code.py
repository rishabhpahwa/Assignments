import random
import sys
import string
from copy import deepcopy

class Node:

	def __init__(self,no,ptable,parents,children,variables):
		self.no=no
		self.ptable=ptable
		self.parents=parents
		self.children=children
		self.variables=variables

def variable_elimination(query, evidence):
	global nodes
	global result
	cpt_factors=[]
	for i in range(len(nodes)):
		cpt_factors.append(Node(0,deepcopy(nodes[i].ptable),[],[],deepcopy(nodes[i].variables)))

	# removing rows not consistent

	for i in range(len(evidence)):
		for j in range(len(cpt_factors)):
			if abs(evidence[i]) in cpt_factors[j].variables:
				temp=[]
				for k in range(len(cpt_factors[j].ptable)):
					if evidence[i] in cpt_factors[j].ptable[k]:
						temp.append(cpt_factors[j].ptable[k])
				cpt_factors[j].ptable=temp
	# print "\n"
	# for i in range(len(cpt_factors)):
	# 	print cpt_factors[i].ptable

	# finding the variables to be eliminated
	tot_var=[]
	for i in range(len(cpt_factors)):
		tot_var.append(i+1)
	q=[]
	e=[]
	for i in range(len(query)):
		q.append(abs(query[i]))
	for i in range(len(evidence)):
		e.append(abs(evidence[i]))
	eliminate_var=[]
	for i in range(len(tot_var)):
		if tot_var[i] in q:
			continue
		elif tot_var[i] in e:
			continue
		else:
			eliminate_var.append(tot_var[i])

	# joining and suming out
	for i in range(len(eliminate_var)):
		factors=[]
		join_and_sum=[]
		for j in range(len(cpt_factors)):
			# print 'varaiables: ' + str(cpt_factors[j].variables)
			if eliminate_var[i] in cpt_factors[j].variables:
				el_fac=Node(0,[],[],[],[])
				el_fac.no=cpt_factors[j].no
				el_fac.ptable=deepcopy(cpt_factors[j].ptable)
				el_fac.variables=deepcopy(cpt_factors[j].variables)
				join_and_sum.append(el_fac)
			else:
				keep_fac=Node(0,[],[],[],[])
				keep_fac.no=cpt_factors[j].no
				keep_fac.ptable=deepcopy(cpt_factors[j].ptable)
				keep_fac.variables=deepcopy(cpt_factors[j].variables)
				factors.append(keep_fac)
		cpt_factors=factors
		# print 'var'+str(eliminate_var[i])
		# print len(cpt_factors)
		# print len(join_and_sum)
		# print '\n'
		# joining
		while(len(join_and_sum)>1):
		# if (len(join_and_sum)>1):
			new_factor=Node(0,[],[],[],[])
			factor1=join_and_sum.pop(0)
			# print factor1.ptable
			factor2=join_and_sum.pop(0)
			# print factor2.ptable
			var=[]	#contains variables in the new factor
			var=factor1.variables
			for a in range(len(factor2.variables)):
				if factor2.variables[a] in var:
					continue
				else:
					var.append(factor2.variables[a])
			new_factor.variables=var
			lim=2**len(new_factor.variables)
			cur_table=[[0 for col in range(len(new_factor.variables)+1)] for row in range(lim)]
			x=lim
			b=0
			while(x>1):
				y=lim
				offset=0
				while(y>0):
					for a in range(0,x/2):
						cur_table[a+offset][b]=int(new_factor.variables[b])
						cur_table[a+x/2+offset][b]=-int(new_factor.variables[b])
						y=y-2
						# print y
					offset=a+x/2+offset+1
				b=b+1
				x=x/2
			new_factor.ptable=deepcopy(cur_table)
			for k in range(len(new_factor.ptable)):
				new_factor.ptable[k][len(new_factor.ptable[k])-1]=float(1)
			# using factor1
			for j in range(len(factor1.ptable)):
				temp_arr=[]
				for z in range(len(factor1.ptable[j])-1):
					temp_arr.append(factor1.ptable[j][z])
				for k in range(len(new_factor.ptable)):
					temp_arr_new=[]
					for y in range(len(new_factor.ptable[k])-1):
						temp_arr_new.append(new_factor.ptable[k][y])
					if all(x in temp_arr_new for x in temp_arr):
						new_factor.ptable[k][len(new_factor.ptable[k])-1] = float((new_factor.ptable[k][len(new_factor.ptable[k])-1]) * (factor1.ptable[j][len(factor1.ptable[j])-1]))
			# print new_factor.ptable
			#using factor2
			for j in range(len(factor2.ptable)):
				temp_arr=[]
				for z in range(len(factor2.ptable[j])-1):
					temp_arr.append(factor2.ptable[j][z])
				for k in range(len(new_factor.ptable)):
					temp_arr_new=[]
					for y in range(len(new_factor.ptable[k])-1):
						temp_arr_new.append(new_factor.ptable[k][y])
					if all(x in temp_arr_new for x in temp_arr):
						new_factor.ptable[k][len(new_factor.ptable[k])-1] = float((new_factor.ptable[k][len(new_factor.ptable[k])-1]) * (factor2.ptable[j][len(factor2.ptable[j])-1]))
			for l in range(len(evidence)):
				if abs(evidence[l]) in new_factor.variables:
					temp=[]
					for k in range(len(new_factor.ptable)):
						if evidence[l] in new_factor.ptable[k]:
							temp.append(new_factor.ptable[k])
					new_factor.ptable=temp
			join_and_sum.append(new_factor)
			# print new_factor.ptable
		# print '\n'
		# print len(join_and_sum)
		# print join_and_sum[0].ptable

		# summing
		new_factor=join_and_sum[0]
		nf=Node(0,[],[],[],[])
		var=[]
		for j in range(len(new_factor.variables)):
			if new_factor.variables[j]!=eliminate_var[i]:
				var.append(new_factor.variables[j])
		nf.variables=var
		lim=2**len(nf.variables)
		cur_table=[[0 for col in range(len(nf.variables)+1)] for row in range(lim)]
		x=lim
		b=0
		while(x>1):
			y=lim
			offset=0
			while(y>0):
				for a in range(0,x/2):
					cur_table[a+offset][b]=int(nf.variables[b])
					cur_table[a+x/2+offset][b]=-int(nf.variables[b])
					y=y-2
					# print y
				offset=a+x/2+offset+1
			b=b+1
			x=x/2
		nf.ptable=deepcopy(cur_table)
		temp=[]
		for k in range(len(nf.ptable)):
			flag=0
			for l in range(len(evidence)):
				if abs(evidence[l]) in nf.variables:
					if evidence[l] in nf.ptable[k]:
						continue
					else:
						flag=1
						break
			if flag==0:
				temp.append(nf.ptable[k])
		nf.ptable=temp
		for j in range(len(nf.ptable)):
			temp_arr=[]
			for z in range(len(nf.ptable[j])-1):
				temp_arr.append(nf.ptable[j][z])
			for k in range(len(new_factor.ptable)):
				temp_arr_new=[]
				for y in range(len(new_factor.ptable[k])-1):
					temp_arr_new.append(new_factor.ptable[k][y])
				if all(x in temp_arr_new for x in temp_arr):
					nf.ptable[j][len(nf.ptable[j])-1] = float((nf.ptable[j][len(nf.ptable[j])-1]) + (new_factor.ptable[k][len(new_factor.ptable[k])-1]))
		# print "\n"
		# print nf.ptable
		cpt_factors.append(nf)
	#variable elimination finishes
	#joining and summing of remaining factors
	join_and_sum=cpt_factors
	while(len(join_and_sum)>1):
		# for i in range(len(join_and_sum)):
		# 	print join_and_sum[i].ptable
		# print '\n'
		# if (len(join_and_sum)>1):
		new_factor=Node(0,[],[],[],[])
		factor1=join_and_sum.pop(0)
		# print factor1.ptable
		factor2=join_and_sum.pop(0)
		# print factor2.ptable
		var=[]	#contains variables in the new factor
		var=factor1.variables
		for a in range(len(factor2.variables)):
			if factor2.variables[a] in var:
				continue
			else:
				var.append(factor2.variables[a])
		new_factor.variables=var
		lim=2**len(new_factor.variables)
		cur_table=[[0 for col in range(len(new_factor.variables)+1)] for row in range(lim)]
		x=lim
		b=0
		while(x>1):
			y=lim
			offset=0
			while(y>0):
				for a in range(0,x/2):
					cur_table[a+offset][b]=int(new_factor.variables[b])
					cur_table[a+x/2+offset][b]=-int(new_factor.variables[b])
					y=y-2
					# print y
				offset=a+x/2+offset+1
			b=b+1
			x=x/2
		new_factor.ptable=deepcopy(cur_table)
		for k in range(len(new_factor.ptable)):
			new_factor.ptable[k][len(new_factor.ptable[k])-1]=float(1)
		# using factor1
		for j in range(len(factor1.ptable)):
			temp_arr=[]
			for z in range(len(factor1.ptable[j])-1):
				temp_arr.append(factor1.ptable[j][z])
			for k in range(len(new_factor.ptable)):
				temp_arr_new=[]
				for y in range(len(new_factor.ptable[k])-1):
					temp_arr_new.append(new_factor.ptable[k][y])
				if all(x in temp_arr_new for x in temp_arr):
					new_factor.ptable[k][len(new_factor.ptable[k])-1] = float((new_factor.ptable[k][len(new_factor.ptable[k])-1]) * (factor1.ptable[j][len(factor1.ptable[j])-1]))
		# print new_factor.ptable
		#using factor2
		for j in range(len(factor2.ptable)):
			temp_arr=[]
			for z in range(len(factor2.ptable[j])-1):
				temp_arr.append(factor2.ptable[j][z])
			for k in range(len(new_factor.ptable)):
				temp_arr_new=[]
				for y in range(len(new_factor.ptable[k])-1):
					temp_arr_new.append(new_factor.ptable[k][y])
				if all(x in temp_arr_new for x in temp_arr):
					new_factor.ptable[k][len(new_factor.ptable[k])-1] = float((new_factor.ptable[k][len(new_factor.ptable[k])-1]) * (factor2.ptable[j][len(factor2.ptable[j])-1]))
		for l in range(len(evidence)):
			if abs(evidence[l]) in new_factor.variables:
				temp=[]
				for k in range(len(new_factor.ptable)):
					if evidence[l] in new_factor.ptable[k]:
						temp.append(new_factor.ptable[k])
				new_factor.ptable=temp
		join_and_sum.append(new_factor)

	# print join_and_sum[0].ptable

	# normalizing the last remaining factor
	tot=float(0)
	for i in range(len(join_and_sum[0].ptable)):
		tot=float(tot+join_and_sum[0].ptable[i][len(join_and_sum[0].ptable[i])-1])
	if tot!=0:
		norm=float(0.0)
		for l in range(len(evidence)):
			if abs(evidence[l]) in join_and_sum[0].variables:
				temp=[]
				for k in range(len(join_and_sum[0].ptable)):
					temp_arr_new=[]
					for y in range(len(join_and_sum[0].ptable[k])-1):
						temp_arr_new.append(new_factor.ptable[k][y])
					if evidence[l] in temp_arr_new:
						temp.append(join_and_sum[0].ptable[k])
				join_and_sum[0].ptable=temp
		# print (join_and_sum[0].ptable)

		for i in range(len(join_and_sum[0].ptable)):
			norm=float(norm+join_and_sum[0].ptable[i][len(join_and_sum[0].ptable[i])-1])
		for i in range(len(join_and_sum[0].ptable)):
			join_and_sum[0].ptable[i][len(join_and_sum[0].ptable[i])-1]=float(join_and_sum[0].ptable[i][len(join_and_sum[0].ptable[i])-1]/norm)
		temp_arr=[]
		for j in range(len(join_and_sum[0].ptable)):
			foo=[]
			for z in range(len(join_and_sum[0].ptable[j])-1):
				foo.append(join_and_sum[0].ptable[j][z])
			temp_arr.append(foo)
		# print join_and_sum[0].ptable
		for i in range(len(join_and_sum[0].ptable)):
			if all(x in temp_arr[i] for x in query):
				# print join_and_sum[0].ptable[i][len(join_and_sum[0].ptable[i])-1]
				result.append("variable elemination: "+str(join_and_sum[0].ptable[i][len(join_and_sum[0].ptable[i])-1]))
				break
	else:
		# print 0.0
		result.append("variable elemination: "+str(0.0))


def reject_sampling(query,evidence):
	global nodes
	global result
	global no_of_samples
	start_nodes=[]
	for i in range(len(nodes)):
		if(len(nodes[i].parents) == 0):
			start_nodes.append(nodes[i])

	assignments=[]
	for i in range(no_of_samples):
		mark=[0 for o in range(len(nodes))]
		flag=0
		assign=[]
		for j in range(0,len(start_nodes)):
			cur_node=start_nodes[j]
			number=random.random()
			if(number < cur_node.ptable[0][len(cur_node.ptable[0])-1]):
				assign.append(cur_node.ptable[0][0])
				mark[cur_node.no-1]=1
			elif(number >= cur_node.ptable[0][len(cur_node.ptable[0])-1]):
				assign.append(cur_node.ptable[1][0])
				mark[cur_node.no-1]=1
			
			for e in range(len(evidence)):
				if(abs(assign[len(assign)-1]) == abs(evidence[e])):
					if (assign[len(assign)-1] != evidence[e]):
						flag=1
						break
			if flag==1:
				break
		if(flag==0):
			queue=[]
			cur_node=start_nodes[0]
			for k in range(len(cur_node.children)):
				queue.append(cur_node.children[k])
			while (len(queue)>0):
				cur_node=queue.pop(0)
				concerned_rows=findrows(assign,cur_node)
				number=random.random()
				if (number < cur_node.ptable[concerned_rows[0]][len(cur_node.ptable[concerned_rows[0]])-1]):
					assign.append(cur_node.ptable[concerned_rows[0]][0])
				elif (number >= cur_node.ptable[concerned_rows[0]][len(cur_node.ptable[concerned_rows[0]])-1]):
					assign.append(cur_node.ptable[concerned_rows[1]][0])

				for e in range(len(evidence)):
					if(abs(assign[len(assign)-1]) == abs(evidence[e])):
						if (assign[len(assign)-1] != evidence[e]):
							flag=1
							break
				if flag==1:
					break

				for gg in range(len(cur_node.children)):
					if (mark[cur_node.children[gg].no-1]==0):
						mark[cur_node.children[gg].no-1]=1
						queue.append(cur_node.children[gg])

		if(flag==0):
			assignments.append(assign)

	count=0
	for i in range(0,len(assignments)):
		if (all(x in assignments[i] for x in query)):
			count=count+1
	if (len(assignments)>0):
		ans=float(count)/len(assignments)
		result.append('rejection sampling: '+str(ans))
	else:
		result.append('rejection sampling: '+str(0.0))

def findrows(assign,cur_node):
	ass_temp=[]
	for i in range(len(cur_node.parents)):
		for j in range(len(assign)):
			if(abs(assign[j]) == abs(cur_node.parents[i].no)):
				ass_temp.append(assign[j])
				break

	assign_temp=deepcopy(ass_temp)
	assign_temp.sort()
	ptable_temp=[]
	for i in range(len(cur_node.ptable)):
		temp=deepcopy(cur_node.ptable[i])
		temp2=deepcopy(temp[1:len(temp)-1])
		temp2.sort()
		ptable_temp.append(temp2)
	res=[]
	for j in range(len(ptable_temp)):
		if (assign_temp == ptable_temp[j]):
			res.append(j)
	
	if (len(res)==2):
		return res	

if (len(sys.argv)==3):
	file_name_inp=sys.argv[1]
	file_name_query=sys.argv[2]
	no_of_samples=2500
elif (len(sys.argv)==4):
	file_name_inp=sys.argv[1]
	file_name_query=sys.argv[2]
	no_of_samples=int(sys.argv[3])
else:
	print "Please re-run the code in the following format: $ python code.py (input_file).txt (query_file).txt {Optional: Number_of_Samples}"
	exit(0)

with open(str(file_name_inp), 'r') as f:
	data1 = f.read()
	data1=data1.strip()
data=data1.splitlines()

nodes=[]
for i in range(int(data[0])):
	nodes.append(Node(i+1,[],[],[],[]))

for i in range(1,len(data),1):
	cur_line=[word.strip(string.punctuation) for word in data[i].split()]
	if (cur_line[0] != None and cur_line[0]!='\n' and float(cur_line[0]) >= 1):
		if (len(cur_line)>1 and (int(cur_line[1])!=0)):
			for k in range(len(nodes)):
				if (nodes[k].no==int(cur_line[0])):
					concerned_node=nodes[k]
					concerned_node.variables.append(k+1)
					break

			for j in range(1,len(cur_line)):
				for k in range(len(nodes)):
					if (nodes[k].no==int(cur_line[j])):
						concerned_parent=nodes[k]
						concerned_node.variables.append(k+1)
						break
				concerned_node.parents.append(concerned_parent)
				concerned_parent.children.append(concerned_node)
			lim=2**(len(cur_line))
			cur_table=[[0 for col in range(len(cur_line)+1)] for row in range(lim)]
			k=0
			for j in range(i+1,(2**(len(cur_line)-1))+i+1):
				cur_line_p=[word.strip(string.punctuation) for word in data[j].split()]
				cur_table[k][len(cur_table[k])-1]=float(cur_line_p[0])
				cur_table[int(k+2**(len(cur_line)-1))][len(cur_table[k])-1]=float(cur_line_p[1])
				k=k+1
			x=lim
			b=0
			while(x>1):
				y=lim
				offset=0
				while(y>0):
					for a in range(0,x/2):
						cur_table[a+offset][b]=int(cur_line[b])
						cur_table[a+x/2+offset][b]=-int(cur_line[b])
						y=y-2
						# print y
					offset=a+x/2+offset+1
				b=b+1
				x=x/2
			concerned_node.ptable=deepcopy(cur_table)
			i=j

		elif(len(cur_line)==1):
			for k in range(len(nodes)):
				if (nodes[k].no==int(cur_line[0])):
					concerned_node=nodes[k]
					concerned_node.variables.append(k+1)
					break
			cur_table=[[0 for col in range(2)] for row in range(2)]
			cur_table[0][0]=int(cur_line[0])
			cur_table[1][0]= -int(cur_line[0])
			cur_line_p=[word.strip(string.punctuation) for word in data[i+1].split()]
			cur_table[0][1]=float(cur_line_p[0])
			cur_table[1][1]=float(cur_line_p[1])
			concerned_node.ptable=deepcopy(cur_table)
			i=i+1

with open(str(file_name_query), 'r') as f:
	data1 = f.read()
	data1=data1.strip()
data_q=data1.splitlines()

result=[]
for i in range(len(data_q)):
	cur_query=data_q[i].replace('~','-').split()
	query=[]
	evidence=[]
	flag=0
	for j in range(1,len(cur_query)):
		if(cur_query[j]=='q'):
			continue
		elif(cur_query[j]=='e'):
			flag=1
			continue
		if (flag==0):
			query.append(int(cur_query[j]))
		elif(flag==1):
			evidence.append(int(cur_query[j]))
	if(cur_query[0]=='rs'):
		reject_sampling(query,evidence)

	elif (cur_query[0]=='ve'):
		variable_elimination(query,evidence)

out=open('output_'+file_name_query,'w')
for i in range(len(result)):
	print >> out, str(i+1)+'. '+str(result[i])