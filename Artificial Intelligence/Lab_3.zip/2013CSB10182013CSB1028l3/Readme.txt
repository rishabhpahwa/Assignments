Readme: 

Problem 1: 
To execute the code type: $ python BS-{Name_of_method}.py in the terminal.
The solved sudoku puzzles will be obtained in output-{Name_of_method}.txt
and the stats can be viewed in stats-{Name_of_method}.txt

Problem 2:
To execute the code type: $ python p2.py in the terminal.
The solved sudoku puzzles output will be obtained in output_minisat.txt

NOTE: Please make sure the input file: 'p.txt' is present in the working directory of the codes.