import time
def FindMRVNode(val,domain):
	[r,c]=[-1,-1]
	minDom=10
	for i in range(9):
		for j in range(9):
			if(val[i][j]=="."):
				temp=len(domain[i][j])
				if temp<minDom:
					minDom=temp
					[r,c]=[i,j]
	return [r,c]

def arcCon(val,domain):
	for i in range(9):
		for j in range(9):
			if(val[i][j]!="."):
				# print "y"
				x=val[i][j]
				# print x
				# print UsedInRow(grid,i,x)
				if(UsedInRow(val,i,x)):
					for k in range(9):
						if(val[i][k]=="."):
							# print "y"
							for l in range(len(domain[i][k])):
								if(domain[i][k][l]==x):
									domain[i][k].remove(x)
									break
				if(UsedInCol(val,j,x)):
					for k in range(9):
						if(val[k][j]=="."):
							for l in range(len(domain[k][j])):
								if(domain[k][j][l]==x):
									domain[k][j].remove(x)
									break
				boxCol = j - j%3
				boxRow = i - i%3
				if(UsedInBox(val,boxRow,boxCol,x)):
					for k in range(3):
						for m in range(3):
							if(val[boxRow+k][boxCol+m]=="."):
								for l in range(len(domain[boxRow+k][boxCol+m])):
									if(domain[boxRow+k][boxCol+m][l]==x):
										domain[boxRow+k][boxCol+m].remove(x)
										break

def UsedInRow(val,row,num):
	for col in range(9):
		if(val[row][col]==num):
			return True
	return False

def UsedInCol(val,col,num):
	for row in range(9):
		if(val[row][col]==num):
			return True
	return False

def UsedInBox(val, boxStartRow, boxStartCol, num):
	for row in range(3):
		for col in range(3):
			if(val[row+boxStartRow][col+boxStartCol]==num):
				return True
	return False

def isSafe(val, row, col, num):
	if(UsedInRow(val, row, num)==False and UsedInCol(val, col, num)==False and UsedInBox(val, row - row%3 , col - col%3, num)==False):
		return True
	else:
		return False

def OrderInLCV(pos,val,domain):
	[r,c]=pos
	tempList=[]
	LCVList=[]
	for j in range(len(domain[r][c])):
		val[r][c]=domain[r][c][j]
		count=0
		for x in range(9):
			if x<c-c%3 or x>=c-c%3+3:
				for k in range(len(domain[r][x])):
					if domain[r][x][k]==val[r][c]:
						count=count+1
		for y in range(9):
			if y<r-r%3 or y>=r-r%3+3:
				for k in range(len(domain[y][c])):
					if domain[y][c][k]==val[r][c]:
						count=count+1
		for x in range(r-r%3,r-r%3+3):
			for y in range(c-c%3,c-c%3+3):
				if x!=r and y!=c:
					for k in range(len(domain[x][y])):
						if domain[x][y][k]==val[r][c]:
							count=count+1
		tempList.append([count,domain[r][c][j]])
	tempList.sort(key=lambda x: x[0])
	for i in range(len(tempList)):
		LCVList.append(tempList[i][1])
	return LCVList

def MRVplusLCV(val,domain):
	global bTracks
	[r,c]=FindMRVNode(val,domain)
	if [r,c]==[-1,-1]:
		return True
	pos=[r,c]
	v=[row[:] for row in val]
	d=[row[:] for row in domain]
	LCVList=OrderInLCV(pos,v,d)

	for i in range(len(LCVList)):
		num=LCVList[i]
		if (isSafe(val, r, c, str(num))):
			val[r][c] = str(num)
			if (MRVplusLCV(val,domain)):
				return True
			bTracks=bTracks+1
			val[r][c] = "."
	return False

stats=open('stats-BS-II.txt','w')
out=open('output-BS-II.txt','w')
with open('p.txt', 'r') as f:
	data = f.read()
games = data.splitlines()
Total_time=0
Total_bTracks=0
for i in range(len(games)):
	domain = [[[] for x in range(9)] for x in range(9)] 
	val = [[0 for x in range(9)] for x in range(9)] 
	for k in range(len(games[i])):
		c=games[i][k]
		if c=='.':
			domain[k/9][k%9]=[str(1),str(2),str(3),str(4),str(5),str(6),str(7),str(8),str(9)]
			val[k/9][k%9]="."
		else:
			val[k/9][k%9]=str(c)
	arcCon(val,domain)
	bTracks=0
	start=time.time()
	MRVplusLCV(val,domain)
	end=time.time()
	tTaken=end-start
	stats.write(str(bTracks))
	stats.write('\t')
	stats.write(str(tTaken))
	stats.write('\n')
	for x in range(9):
		for y in range(9):
			out.write(val[x][y])
	out.write('\n')
stats.write("Total Time: "+str(Total_time)+'\nAverage Time: '+str(Total_time/len(games)) + '\nAverage Backtracks: '+str(Total_bTracks/len(games)))