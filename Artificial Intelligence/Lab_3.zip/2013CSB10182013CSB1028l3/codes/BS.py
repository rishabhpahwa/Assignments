import time
class cell:
	def __init__(self):
		self.index=[]
		self.domain=[]
		self.peers=[]
		self.val=0
		self.row=0
		self.col=0
		self.box=0

def FindUnassignedLoc(grid):
	for i in range(9):
		for j in range(9):
			if(grid[i][j].val=="."):
				return [i,j]
	return [-1,-1]

def UsedInRow(grid,row,num):
	for col in range(9):
		if(grid[row][col].val==num):
			return True
	return False

def UsedInCol(grid,col,num):
	for row in range(9):
		if(grid[row][col].val==num):
			return True
	return False

def UsedInBox(grid, boxStartRow, boxStartCol, num):
	for row in range(3):
		for col in range(3):
			if(grid[row+boxStartRow][col+boxStartCol].val==num):
				return True
	return False

def isSafe(grid, row, col, num):
	if(UsedInRow(grid, row, num)==False and UsedInCol(grid, col, num)==False and UsedInBox(grid, row - row%3 , col - col%3, num)==False):
		return True
	else:
		return False

def arcCon(grid):
	for i in range(9):
		for j in range(9):
			if(grid[i][j].val!="."):
				# print "y"
				x=grid[i][j].val
				# print x
				# print UsedInRow(grid,i,x)
				if(UsedInRow(grid,i,x)):
					for k in range(9):
						if(grid[i][k].val=="."):
							# print "y"
							for l in range(len(grid[i][k].domain)):
								if(grid[i][k].domain[l]==x):
									grid[i][k].domain.remove(x)
									break
				if(UsedInCol(grid,j,x)):
					for k in range(9):
						if(grid[k][j].val=="."):
							for l in range(len(grid[k][j].domain)):
								if(grid[k][j].domain[l]==x):
									grid[k][j].domain.remove(x)
									break
				boxCol = j - j%3
				boxRow = i - i%3
				if(UsedInBox(grid,boxRow,boxCol,x)):
					for k in range(3):
						for m in range(3):
							if(grid[boxRow+k][boxCol+m].val=="."):
								for l in range(len(grid[boxRow+k][boxCol+m].domain)):
									if(grid[boxRow+k][boxCol+m].domain[l]==x):
										grid[boxRow+k][boxCol+m].domain.remove(x)
										break
	return grid

def BS(grid):
	global bTracks
	[r,c]=FindUnassignedLoc(grid)
	if [r,c]==[-1,-1]:
		return True
	for i in range(len(grid[r][c].domain)):
		num=grid[r][c].domain[i]
		if (isSafe(grid, r, c, str(num))):
			grid[r][c].val = str(num)
			if (BS(grid)):
				return True
			bTracks=bTracks+1
			grid[r][c].val = "."
	return False


stats=open('stats-BS.txt','w')
out=open('output-BS.txt','w')
with open('p.txt', 'r') as f:
	data = f.read()
games = data.splitlines()
Total_time=0
Total_bTracks=0
for i in range(len(games)):
	grid = [[cell() for j in range(9)] for l in range(9)]
	for k in range(len(games[i])):
		c=games[i][k]
		node=cell()
		if c=='.':
			node.domain=[str(1),str(2),str(3),str(4),str(5),str(6),str(7),str(8),str(9)]
			node.val="."
		else:
			node.val=str(c)
		grid[k/9][k%9]=node
	grid=arcCon(grid)
	# print 'y'
	bTracks=0
	start=time.time()
	val=BS(grid)
	end=time.time()
	tTaken=end-start
	Total_time+=tTaken
	Total_bTracks+=bTracks
	stats.write(str(bTracks))
	stats.write('\t')
	stats.write(str(tTaken))
	stats.write('\n')
	for x in range(9):
		for y in range(9):
			out.write(grid[x][y].val)
	out.write('\n')
stats.write("Total Time: "+str(Total_time)+'\nAverage Time: '+str(Total_time/len(games)) + '\nAverage Backtracks: '+str(Total_bTracks/len(games)))