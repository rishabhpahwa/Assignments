from copy import deepcopy
import time
def FindMRVNode(val,domain):
	[r,c]=[-1,-1]
	minDom=10
	for i in range(9):
		for j in range(9):
			if(val[i][j]=="."):
				temp=len(domain[i][j])
				if temp<minDom:
					minDom=temp
					[r,c]=[i,j]
	return [r,c]

def arcCon(val,domain):
	for i in range(9):
		for j in range(9):
			if(val[i][j]!="."):
				x=val[i][j]
				if(UsedInRow(val,i,x)):
					for k in range(9):
						if(val[i][k]=="."):
							# print "y"
							for l in range(len(domain[i][k])):
								if(domain[i][k][l]==x):
									domain[i][k].remove(x)
									break
				if(UsedInCol(val,j,x)):
					for k in range(9):
						if(val[k][j]=="."):
							for l in range(len(domain[k][j])):
								if(domain[k][j][l]==x):
									domain[k][j].remove(x)
									break
				boxCol = j - j%3
				boxRow = i - i%3
				if(UsedInBox(val,boxRow,boxCol,x)):
					for k in range(3):
						for m in range(3):
							if(val[boxRow+k][boxCol+m]=="."):
								for l in range(len(domain[boxRow+k][boxCol+m])):
									if(domain[boxRow+k][boxCol+m][l]==x):
										domain[boxRow+k][boxCol+m].remove(x)
										break
	return [val,domain]

def UsedInRow(val,row,num):
	for col in range(9):
		if(val[row][col]==num):
			return True
	return False

def UsedInCol(val,col,num):
	for row in range(9):
		if(val[row][col]==num):
			return True
	return False

def UsedInBox(val, boxStartRow, boxStartCol, num):
	for row in range(3):
		for col in range(3):
			if(val[row+boxStartRow][col+boxStartCol]==num):
				return True
	return False

def isSafe(val, row, col, num):
	if(UsedInRow(val, row, num)==False and UsedInCol(val, col, num)==False and UsedInBox(val, row - row%3 , col - col%3, num)==False):
		return True
	else:
		return False

def MRV(val,domain):
	global bTracks
	[r,c]=FindMRVNode(val,domain)
	if [r,c]==[-1,-1]:
		return deepcopy(val)
	for i in range(len(domain[r][c])):
		num=domain[r][c][i]
		if (isSafe(val, r, c, str(num))):
			childVal=deepcopy(val)
			childDomain=deepcopy(domain)
			childVal[r][c] = str(num)
			retVal=MRV(childVal,childDomain)
			if (retVal!=False):
				return retVal
			bTracks=bTracks+1
	return False

stats=open('stats-BS-I.txt','w')
out=open('output-BS-I.txt','w')
with open('p.txt', 'r') as f:
	data = f.read()
games = data.splitlines()
Total_time=0
Total_bTracks=0
for i in range(len(games)):
	domain = [[[] for x in range(9)] for x in range(9)] 
	val = [[0 for x in range(9)] for x in range(9)] 
	for k in range(len(games[i])):
		c=games[i][k]
		if c=='.':
			domain[k/9][k%9]=[str(1),str(2),str(3),str(4),str(5),str(6),str(7),str(8),str(9)]
			val[k/9][k%9]="."
		else:
			val[k/9][k%9]=str(c)
	# print('\n'.join([''.join(['{:>2}'.format(item) for item in row]) for row in val]))
	arcCon(val,domain)
	# print 'y'
	bTracks=0
	start=time.time()
	val=MRV(val,domain)
	end=time.time()
	tTaken=end-start
	stats.write(str(bTracks))
	stats.write('\t')
	stats.write(str(tTaken))
	stats.write('\n')
	# print('\n'.join([''.join(['{:>2}'.format(item) for item in row]) for row in val]))
	for x in range(9):
		for y in range(9):
			out.write(val[x][y])
	out.write('\n')
stats.write("Total Time: "+str(Total_time)+'\nAverage Time: '+str(Total_time/len(games)) + '\nAverage Backtracks: '+str(Total_bTracks/len(games)))