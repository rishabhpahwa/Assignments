import os
import timeit
start=timeit.default_timer()
with open('p.txt', 'r') as f:
    data = f.read()
outt=open('output_minisat.txt','w')
games = data.splitlines()
game=games
count = 0
while (len(game)>0):
    cur_game=game.pop(0)
    count+=1
    board=[[0 for i in range(9)] for j in range(9)]
    i=0
    while(i<len(cur_game)):
        row=int(i/9)
        col=i%9
        board[row][col]=cur_game[i]
        i=i+1
    var=[[[0 for o in range(9)] for oo in range(9)] for ooo in range(9)]
    for j in range(len(board)):
        for k in range(len(board[j])):
            if (board[j][k]!='.'):
                var[j][k][int(board[j][k])-1]=1
    clauses=[]
    for j in range(0,len(var)):
        for k in range(0,len(var[j])):
            for l in range(0,len(var[j][k])):
                #checking for given true variables
                if (var[j][k][l]==1):
                    clauses.append(str(((j+1)*10*10)+((k+1)*10)+l+1)+' 0')
            res=''
            # Each square has atleast one of the 9 values.
            for m in range(0,len(var[j][k])):
                res+=str(((j+1)*10*10)+((k+1)*10)+m+1)+' '
            res+='0'
            clauses.append(res)
            # Each square has atmost 1 true value.
            for m in range(0,len(var[j][k])):
                res1=''
                for n in range(m+1,9):
                    res1=str(-(((j+1)*10*10)+((k+1)*10)+m+1))+' '+str(-(((j+1)*10*10)+((k+1)*10)+n+1))+' 0'
                    clauses.append(res1)

    for j in range(0,len(var[0][0])):
    # Sweep entire board for 1 to 9 values.
        for row in range(0,len(var),3):
            for col in range(0,len(var[row]),3):
                # Atleast 1 j in the subsquare of sudoku board.
                res3=str((row+1)*100 + (col+1)*10 + j+1)+' '+str((row+1)*100 + (col+2)*10 + j+1)+' '+str((row+1)*100 + (col+3)*10 + j+1)+' '+str((row+2)*100 + (col+1)*10 + j+1)+' '+str((row+2)*100 + (col+2)*10 + j+1)+' '+str((row+2)*100 + (col+3)*10 + j+1)+' '+str((row+3)*100 + (col+1)*10 + j+1)+' '+str((row+3)*100 + (col+2)*10 + j+1)+' '+str((row+3)*100 + (col+3)*10 + j+1)+' '+'0'
                clauses.append(res3)
                res4=''
                # For atmost one j in the subsquare.
                matr=[[0 for o in range(3)] for oo in range(3)]
                for v in range(0,9):
                    flag=0
                    for r1 in range(0,3):
                        for c1 in range(0,3):
                            if (matr[r1][c1]==0):
                                row1=r1
                                col1=c1
                                matr[r1][c1]=1
                                flag=1
                                break
                        if (flag==1):
                            break

                    for r in range(0,3):
                        for c in range(0,3):
                            if(matr[r][c]==0):
                                res4=str(-(((r+row+1)*10*10)+((c+col+1)*10)+j+1))+' '+str(-(((row1+row+1)*100) + ((col1+col+1)*10)+j+1))+' 0'
                                clauses.append(res4)

        # Exactly one j in a row.
        for k in range(0,len(var)):
            resR=''
            for l in range(0,len(var[j])):
                resR+=str((k+1)*100 + (l+1)*10 + j+1)+' '
            resR+='0'
            clauses.append(resR)
            for m in range(1,10):
                res1=''
                for n in range(m+1,10):
                    res1=str(-(((k+1)*10*10)+((m)*10)+j+1))+' '+str(-(((k+1)*10*10)+((n)*10)+j+1))+' 0'
                    clauses.append(res1)

        for kk in range(0,len(var)):
            resC=''
            for ll in range(0,len(var[j])):
                resC+=str((ll+1)*100 + (kk+1)*10 + j+1)+' '
            resC+='0'
            clauses.append(resC)
            for mm in range(1,len(var)+1):
                res1=''
                for nn in range(mm+1,len(var)+1):
                    res1=str(-(((mm)*10*10)+((kk+1)*10)+j+1))+' '+str(-(((nn)*10*10)+((kk+1)*10)+j+1))+' 0'
                    clauses.append(res1)

    f=open('test','w')
    print >> f, 'p cnf '+str(len(var)*len(var)*len(var))+' '+str(len(clauses))
    for x in range(len(clauses)):
        print >> f, str(clauses[x])
    f.close()
    os.system('minisat test out.txt')

    with open('out.txt', 'r') as o:
        result = o.read()
    res=result.split()
    final=''
    if(res[0]=='SAT'):
        for i in range(1,len(res)):
            if(int(res[i]) > 0):
                final+=str(int(res[i])%10)
    else:
        final+='UNSAT'
    print >> outt,final
os.remove('out.txt')
os.remove('test')
stop=timeit.default_timer()
print "Time Taken: " + str(stop-start)