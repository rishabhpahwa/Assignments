import string
import sys
from copy import deepcopy
import time

class Node:

	def __init__(self,N,onTable,clear,on,hold,empty,parent,action,param,cnt):
		self.onTable=onTable
		self.clear=clear
		self.on=on
		self.hold=hold
		self.empty=empty
		self.parent=parent
		self.action=action
		self.param=param
		self.cnt=cnt

def pick(cur_node,blockNum):
	global queue
	global heuristics
	global method
	if cur_node.onTable[blockNum-1]==1 and cur_node.clear[blockNum-1]==1 and cur_node.empty==1:
		child_node=Node(N,deepcopy(cur_node.onTable),deepcopy(cur_node.clear),deepcopy(cur_node.on),deepcopy(cur_node.hold),cur_node.empty,cur_node,deepcopy(cur_node.action),deepcopy(cur_node.param),deepcopy(cur_node.cnt)+1)
		child_node.hold[blockNum-1]=1
		child_node.clear[blockNum-1]=0
		child_node.empty=0
		child_node.onTable[blockNum-1]=0
		child_node.action = "pick("+str(blockNum)+")"
		if(method == 'a'):
			child_node.param=max(match(child_node),cur_node.param)
			heuristics.append(child_node.param)
		queue.append(child_node)
		return True
	return False

def unstack(cur_node,blockAnum,blockBnum):
	global queue
	global heuristics
	if cur_node.on[blockBnum-1]==blockAnum and cur_node.clear[blockAnum-1]==1 and cur_node.empty==1:
		child_node=Node(N,deepcopy(cur_node.onTable),deepcopy(cur_node.clear),deepcopy(cur_node.on),deepcopy(cur_node.hold),cur_node.empty,cur_node,deepcopy(cur_node.action),deepcopy(cur_node.param),deepcopy(cur_node.cnt)+1)
		child_node.hold[blockAnum-1]=1
		child_node.clear[blockBnum-1]=1
		child_node.on[blockBnum-1]=0
		child_node.empty=0
		child_node.clear[blockAnum-1]=0
		child_node.action = "unstack("+str(blockAnum)+","+str(blockBnum)+")"
		if(method == 'a'):
			child_node.param=max(match(child_node),cur_node.param)
			heuristics.append(child_node.param)
		queue.append(child_node)
		return True
	return False

def release(cur_node,blockNum):
	global queue
	global heuristics
	if cur_node.hold[blockNum-1]==1:
		child_node=Node(N,deepcopy(cur_node.onTable),deepcopy(cur_node.clear),deepcopy(cur_node.on),deepcopy(cur_node.hold),cur_node.empty,cur_node,deepcopy(cur_node.action),deepcopy(cur_node.param),deepcopy(cur_node.cnt)+1)
		child_node.onTable[blockNum-1]=1
		child_node.clear[blockNum-1]=1
		child_node.empty=1
		child_node.hold[blockNum-1]=0
		child_node.action = "release("+str(blockNum)+")"
		if(method == 'a'):
			child_node.param=max(match(child_node),cur_node.param)
			heuristics.append(child_node.param)
		queue.append(child_node)
		return True
	return False

def stack(cur_node,blockAnum, blockBnum):
	global queue
	global heuristics
	if (cur_node.clear[blockBnum-1]==1 and cur_node.hold[blockAnum-1]==1):
		child_node=Node(N,deepcopy(cur_node.onTable),deepcopy(cur_node.clear),deepcopy(cur_node.on),deepcopy(cur_node.hold),cur_node.empty,cur_node,deepcopy(cur_node.action),deepcopy(cur_node.param),deepcopy(cur_node.cnt)+1)
		child_node.on[blockBnum-1] = blockAnum
		child_node.clear[blockAnum-1] = 1
		child_node.empty = 1
		child_node.hold[blockAnum-1] = 0
		child_node.clear[blockBnum-1] = 0
		child_node.action = "stack("+str(blockAnum)+","+str(blockBnum)+")"
		if(method == 'a'):
			child_node.param=max(match(child_node),cur_node.param)
			heuristics.append(child_node.param)
		queue.append(child_node)
		return True
	return False

def match(child_node):
	global goal
	count=0
	cur_cnt=child_node.cnt
	for i in range(0,len(child_node.on)):
		if(child_node.on[i]==0):
			child_node.clear[i]=1
		if (goal.onTable[i]==1 and goal.onTable[i]!=child_node.onTable[i]): #goal.onTable[i]==1 and 
			j=i
			while (child_node.clear[j]!=1):
				count+=2
				j=child_node.on[j]-1
			count+=2
		if (goal.on[i]>0 and goal.on[i]!=child_node.on[i]): #goal.on[i]>0 and 
			j=i
			jj=goal.on[i]-1
			flag=0
			while (child_node.clear[j]!=1):
				count+=2
				j=child_node.on[j]-1
			count+=2
		if (child_node.hold[i]>0): #goal.hold[i]==1 and ## goal.hold[i]==1 and goal.hold[i]!=
			count+=1
		if (goal.clear[i]==1 and goal.clear[i]!=child_node.clear[i]): #goal.clear[i]==1 and 
			j=i
			while (child_node.clear[j]!=1):
				count+=2
				j=child_node.on[j]-1
			count+=1
	if (goal.empty!=child_node.empty):
		count+=1
	return count + cur_cnt

def match_nodes(v_nodes,cur_node):
	for i in range(len(v_nodes)):
		if (v_nodes[i].onTable == cur_node.onTable and v_nodes[i].on == cur_node.on and v_nodes[i].hold == cur_node.hold): #  and v_nodes[i].clear == cur_node.clear and v_nodes[i].empty == cur_node.empty
			return True
	return False

def BFS ():
	global queue
	global N
	global goal
	global file_name
	flag=0
	nodes_expand=0
	while(len(queue)>0):
		nodes_expand+=1
		cur_node=queue.pop(0)
		cur_onTable=cur_node.onTable[:]
		cur_hold=cur_node.hold[:]
		cur_on=cur_node.on[:]
		cur_empty=cur_node.empty
		cur_clear=cur_node.clear[:]
		if (cur_onTable == goal.onTable and cur_clear == goal.clear and cur_hold == goal.hold and cur_on == goal.on and cur_empty==goal.empty):
			flag=1
			break
		for i in range(N):
			pick(cur_node,i+1)
			release(cur_node,i+1)
			for j in range(N):
				if(i!=j):
					unstack(cur_node,i+1,j+1)
					stack(cur_node,i+1,j+1)
	action=''
	count=0
	out=open('output_'+file_name,'w')
	if(flag==1):
		while(cur_node!=None):
			if(cur_node.action != None):
				action=cur_node.action+'\n'+action
				count+=1
			cur_node=cur_node.parent
		print >> out, count
		print >> out, action
		print "Number of nodes expanded: "+str(nodes_expand)
	elif (flag==0):
		print "No Solution."

def AStar ():
	global queue
	global N
	global goal
	global heuristics
	flag=0
	global v_nodes
	global file_name
	nodes_expand=0
	while(len(queue)>0):
		cur_node=queue.pop(0)
		cur_heur=heuristics.pop(0)
		if (match_nodes(v_nodes,cur_node) == False):
			nodes_expand+=1
			v_nodes.append(cur_node)
			cur_onTable=cur_node.onTable[:]
			cur_hold=cur_node.hold[:]
			cur_on=cur_node.on[:]
			cur_empty=cur_node.empty
			cur_clear=cur_node.clear[:]
			if (cur_onTable == goal.onTable and cur_clear == goal.clear and cur_hold == goal.hold and cur_on == goal.on and cur_empty==goal.empty): # and cur_empty==goal.empty
				flag=1
				break
			for i in range(N):
				pick(cur_node,i+1)
				for j in range(N):
					if(i!=j):
						stack(cur_node,i+1,j+1)
						unstack(cur_node,i+1,j+1)
				release(cur_node,i+1)
			queue=[a for (b,a) in sorted(zip(heuristics,queue), key=lambda x: x[0])]
			heuristics.sort()

	action=''
	count=0
	out=open('output_'+file_name,'w')
	if(flag==1):
		while(cur_node!=None):
			if(cur_node.action != None):
				action=cur_node.action+'\n'+action
				count+=1
			cur_node=cur_node.parent
		print >> out, count
		print >> out, action
		print "Number of nodes expanded: "+str(nodes_expand)
	elif (flag==0):
		print "No Solution."

def goalStack():
	global goal
	global initial
	global N
	stack=[]
	actionPlan=[]
	stack.append(("g","goal",goal,-1))
	for i in range(N):
		if goal.onTable[i]==1:
			stack.append(("p","ontable",i+1,-1))
	for i in range(N):
		if goal.clear[i]==1:
			stack.append(("p","clear",i+1,-1))
	for i in range(N):
		if goal.on[i]!=0:
			stack.append(("p","on",goal.on[i],i+1)) #paraA on paraB
	for i in range(N):
		if goal.hold[i]==1:
			stack.append(("p","hold",i+1,-1))
	if goal.empty==1:
		stack.append(("p","empty",1,-1))
	else:
		stack.append(("p","empty",0,-1))
	# print initial.clear
	# print initial.onTable
	# print initial.on
	# print initial.hold
	# print stack
	while len(stack)>0:
		# print len(stack)
		# print stack
		# print '\n'
		(element,string,paraA,paraB) = stack[len(stack)-1]
		if element=="g":
			if string == "pick":
				flag=0
				for i in range(N):
					if paraA.onTable[i]!=0:
						if initial.onTable[i]!=paraA.onTable[i]:
							flag=1
				for i in range(N):
					if paraA.clear[i]!=0:
						if initial.clear[i]!=paraA.clear[i]:
							flag=1
				if paraA.empty!=0:
					if initial.empty!=paraA.empty:
							flag=1
				if flag==0:
					stack.pop()
				else:
					for i in range(N):
						if paraA.onTable[i]==1:
							stack.append(("p","ontable",i+1,-1))		#i+1 = actual block number
					for i in range(N):
						if paraA.clear[i]==1:
							stack.append(("p","clear",i+1,-1))
					if paraA.empty==1:
						stack.append(("p","empty",1,-1))
					else:
						stack.append(("p","empty",0,-1))

			if string == "unstack":
				flag=0
				for i in range(N):
					if paraA.clear[i]!=0:
						if initial.clear[i]!=paraA.clear[i]:
							flag=1
				for i in range(N):
					if paraA.on[i]!=0:
						if initial.on[i]!=paraA.on[i]:
							flag=1
				if paraA.empty!=0:
					if initial.empty!=paraA.empty:
							flag=1				
				if flag==0:
					stack.pop()
				else:
					for i in range(N):
						if paraA.clear[i]==1:
							stack.append(("p","clear",i+1,-1))
					for i in range(N):
						if paraA.on[i]!=0:
							stack.append(("p","on",paraA.on[i],i+1))
					if paraA.empty==1:
						stack.append(("p","empty",1,-1))
					else:
						stack.append(("p","empty",0,-1))

			if string == "release":
				flag=0
				for i in range(N):
					if paraA.hold[i]!=0:
						if initial.hold[i]!=paraA.hold[i]:
							flag=1
				if flag==0:
					stack.pop()
				else:
					for i in range(N):
						if paraA.hold[i]==1:
							stack.append(("p","hold",i+1,-1))

			if string == "stack":
				flag=0
				for i in range(N):
					if paraA.clear[i]!=0:
						if initial.clear[i]!=paraA.clear[i]:
							flag=1
				for i in range(N):
					if paraA.hold[i]!=0:
						if initial.hold[i]!=paraA.hold[i]:
							flag=1
				if flag==0:
					stack.pop()
				else:
					for i in range(N):
						if paraA.clear[i]==1:
							stack.append(("p","clear",i+1,-1))
					for i in range(N):
						if paraA.hold[i]==1:
							stack.append(("p","hold",i+1,-1))


			if string == "goal":
				flag=0
				for i in range(N):
					if paraA.onTable[i]!=0:
						if initial.onTable[i]!=paraA.onTable[i]:
							flag=1
				for i in range(N):
					if paraA.clear[i]!=0:
						if initial.clear[i]!=paraA.clear[i]:
							flag=1
				for i in range(N):
					if paraA.on[i]!=0:
						if initial.on[i]!=paraA.on[i]:
							flag=1
				for i in range(N):
					if paraA.hold[i]!=0:
						if initial.hold[i]!=paraA.hold[i]:
							flag=1
				if paraA.empty!=0:
					if initial.empty!=paraA.empty:
							flag=1
					# flag=1
				# print flag
				if flag==0:
					stack.pop()
				else:
					for i in range(N):
						if paraA.onTable[i]==1:
							stack.append(("p","ontable",i+1,-1))		#i+1 = actual block number
					for i in range(N):
						if paraA.clear[i]==1:
							stack.append(("p","clear",i+1,-1))
					for i in range(N):
						if paraA.on[i]!=0:
							stack.append(("p","on",paraA.on[i],i+1))
					for i in range(N):
						if paraA.hold[i]==1:
							stack.append(("p","hold",i+1,-1))
					if paraA.empty==1:
						stack.append(("p","empty",1,-1))
					else:
						stack.append(("p","empty",0,-1))

		if element=="p":
			# ontable = release
			# on = stack
			# clear = unstack, release
			# hold = pick, unstack
			# empty = release
			if string=="ontable":
				if initial.onTable[paraA-1]==1:
					stack.pop()
				else:
					stack.append(("a","release",paraA,-1))
					precond = Node(N,[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],1,None,None,None,0)
					precond.hold[paraA-1]=1
					stack.append(("g","release",precond,-1))
					stack.append(("p","hold",paraA,-1))
			
			if string=="on":
				#paraA on paraB
				if initial.on[paraB-1]==paraA:
					stack.pop()
				else:
					stack.append(("a","stack",paraA,paraB))
					precond = Node(N,[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],1,None,None,None,0)
					precond.clear[paraB-1]=1
					precond.hold[paraA-1]=1
					stack.append(("g","stack",precond,-1))
					stack.append(("p","clear",paraB,-1))
					stack.append(("p","hold",paraA,-1))
			
			if string=="hold":
				if initial.hold[paraA-1]==1:
					stack.pop()
				else:
					paraB=-1
					for i in range(N):
						if initial.on[i]==paraA:
							paraB=i+1
							break
					if paraB==-1:
						stack.append(("a","pick",paraA,-1))
						precond = Node(N,[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],1,None,None,None,0)
						precond.onTable[paraA-1]=1
						precond.clear[paraA-1]=1
						precond.empty=1
						stack.append(("g","pick",precond,-1))
						stack.append(("p","ontable",paraA,-1))
						stack.append(("p","clear",paraA,-1))
						stack.append(("p","empty",1,-1))
					else:
						stack.append(("a","unstack",paraA,paraB))
						precond = Node(N,[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],1,None,None,None,0)
						precond.on[paraB-1]=paraA
						precond.clear[paraA-1]=1
						precond.empty=1
						stack.append(("g","unstack",precond,-1))
						stack.append(("p","on",paraA,paraB))
						stack.append(("p","clear",paraA,-1))
						stack.append(("p","empty",1,-1))
			
			if string=="clear":
				if initial.clear[paraA-1]==1:
					stack.pop()
				else:
					if initial.on[paraA-1]==0:
						stack.append(("a","release",paraA,-1))
						precond = Node(N,[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],1,None,None,None,0)
						precond.hold[paraA-1]=1
						stack.append(("g","release",precond,-1))
						stack.append(("p","hold",paraA,-1))
					else:
						paraB=initial.on[paraA-1]
						stack.append(("a","unstack",paraB,paraA))
						precond = Node(N,[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],1,None,None,None,0)
						precond.on[paraA-1]=paraB
						precond.clear[paraB-1]=1
						precond.empty=1
						stack.append(("g","unstack",precond,-1))
						stack.append(("p","on",paraB,paraA))
						stack.append(("p","clear",paraB,-1))
						stack.append(("p","empty",1,-1))

			if string=="empty":
				if initial.empty==1:
					stack.pop()
				else:
					for i in range(N):
						if initial.hold[i]==1:
							paraA=i+1
							break
					stack.append(("a","release",paraA,-1))
					precond = Node(N,[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],[0 for i in range(N)],1,None,None,None,0)
					precond.hold[paraA-1]=1
					stack.append(("g","release",precond,-1))
					stack.append(("p","hold",paraA,-1))


		if element=="a":
			if string == "release":
				actionPlan.append(("release("+str(paraA)+")"))
				initial.onTable[paraA-1]=1
				initial.clear[paraA-1]=1
				initial.empty=1
				initial.hold[paraA-1]=0
			if string == "pick":
				actionPlan.append(("pick("+str(paraA)+")"))
				initial.hold[paraA-1]=1
				initial.clear[paraA-1]=0
				initial.empty=0
				initial.onTable[paraA-1]=0
			if string == "stack":
				actionPlan.append(("stack("+str(paraA)+","+str(paraB)+")"))
				initial.on[paraB-1]=paraA
				initial.clear[paraA-1]=1
				initial.empty=1
				initial.hold[paraA-1]=0
				initial.clear[paraB-1]=0
			if string == "unstack":
				actionPlan.append(("unstack("+str(paraA)+","+str(paraB)+")"))
				initial.hold[paraA-1]=1
				initial.clear[paraB-1]=1
				initial.on[paraB-1]=0
				initial.empty=0
				initial.clear[paraA-1]=0
			stack.pop()
			
	output = open("output_"+file_name, "w")
	output.write(str(len(actionPlan)))
	output.write("\n")
	for i in range(len(actionPlan)):
		output.write(actionPlan[i])
		output.write("\n")
	output.close()

if (len(sys.argv)>1):
	file_name=sys.argv[1]
else:
	print "Please re-run the code with some valid input file name."
	exit(0)

with open(str(file_name), 'r') as f:
	data1 = f.read()
data=data1.splitlines()
N=int(data[0])
method=data[1]
v_nodes=[]
i_state=[word.strip(string.punctuation) for word in data[3].split()]

i_onTable=[0 for i in range(N)]
i_on=[0 for i in range(N)]
i_clear=[0 for i in range(N)]
i_hold=[0 for i in range(N)]
i_empty=0

while(len(i_state)>0):
	cur_prop=i_state.pop(0)
	if(cur_prop == 'ontable'):
		i_onTable[int(i_state.pop(0))-1]=1
	elif (cur_prop == 'clear'):
		i_clear[int(i_state.pop(0))-1]=1
	elif (cur_prop == 'on'):
		no_1=int(i_state.pop(0))
		no_2=int(i_state.pop(0))
		i_on[no_2-1]=no_1
	elif (cur_prop == 'empty'):
		i_empty=1
	elif (cur_prop == 'hold'):
		i_hold[int(i_state.pop(0))-1]=1

initial=Node(N,i_onTable[:],i_clear[:],i_on[:],i_hold[:],i_empty,None,None,0,0)
heuristics=[]
heuristics.append(0)
g_state=[word.strip(string.punctuation) for word in data[5].split()]
# print g_state

g_onTable=[0 for i in range(N)]
g_on=[0 for i in range(N)]
g_clear=[0 for i in range(N)]
g_hold=[0 for i in range(N)]
g_empty=0

while(len(g_state)>0):
	cur_prop=g_state.pop(0)
	if(cur_prop == 'ontable'):
		g_onTable[int(g_state.pop(0))-1]=1
	elif (cur_prop == 'clear'):
		g_clear[int(g_state.pop(0))-1]=1
	elif (cur_prop == 'on'):
		no_1=int(g_state.pop(0))
		no_2=int(g_state.pop(0))
		g_on[no_2-1]=no_1
	elif (cur_prop == 'empty'):
		g_empty=1
	elif (cur_prop == 'hold'):
		g_hold[int(g_state.pop(0))-1]=1

goal=Node(N,g_onTable[:],g_clear[:],g_on[:],g_hold[:],g_empty,None,None,0,0)
queue=[]
start = time.time()
if(method == 'f'):
	queue.append(initial)
	res=BFS()
elif(method == 'a'):
	queue.append(initial)
	res=AStar()
elif(method == 'g'):
    res=goalStack()
print 'Time taken: '+str(time.time() - start)