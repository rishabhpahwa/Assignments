CSL 452: Artificial Intelligence
Lab-4

Group members:
1. Milind Aggarwal: 2013CSB1018
2. Rishabh Pahwa: 2013CSB1028


Readme,

To run the program navigate to the current working directory and execute the following
command in the terminal:

$ python code.py {text file input}

The output of the file will be saved in the current directory as 'output_{text file input}.txt'