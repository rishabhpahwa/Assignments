##Takes the input currentBoardState and
##return a list of two objects initial position and Final Position
##Board is in form of 2-D list where left top is [0,0] and right Bottom is [4,4]

##In Board
##0 -> Empty Location
##1 -> Musketeer
##2 -> soldier

class node:

    def __init__(self,alpha,beta,value,data,camefrom,gaps,board,parent,n_type,trace,children):
        self.alpha=alpha
        self.beta=beta
        self.value=value
        self.data=data
        self.parent=parent
        self.n_type=n_type
        self.children=children
        self.camefrom=camefrom
        self.gaps=gaps
        self.board=board
        self.trace=trace

def musketeerMove(board):
    a=[dfe[:] for dfe in board]
    muskpos=[]
    gappos=[]
    #print board
    for i in range(len(board)):
        for j in range(len(board[i])):
            if (a[i][j]==1):
                muskpos.append([i,j])
            elif (a[i][j]==0):
                gappos.append([i,j])
    alp=-float('Inf')
    bet=float('Inf')
    value=-float('Inf')
    n=node(alp,bet,value,muskpos,None,gappos,[d[:]for d in a],None,'max',None,[])
    k=0
    gen_tree(n,k)
    for i in range(len(n.data)):
        if(n.trace.data[i]!=n.data[i]):
            return [n.data[i],n.trace.data[i]]

def gen_tree(root,k):
    if(k==5):
        muskpos=root.data
        root.value=max(abs(muskpos[0][0]-muskpos[1][0]),abs(muskpos[0][1]-muskpos[1][1])) + max(abs(muskpos[1][0]-muskpos[2][0]),abs(muskpos[1][1]-muskpos[2][1])) + max(abs(muskpos[0][0]-muskpos[2][0]),abs(muskpos[0][1]-muskpos[2][1]))
        return root.value
        #print root.value

    elif (k%2==0):
        #print root.data, " : ", root.board
        queue=child_gen_musk(root,root.alpha,root.beta)
        if (k==0):
            root.trace=queue[0]
        #print len(queue)," : ",k
        while (len(queue)>0):
            x=queue.pop(0)
            res1=gen_tree(x,k+1)
            if(res1>root.alpha):
                root.alpha=res1
                for o in range(len(queue)):
                    queue[o].alpha=res1
                if (root.parent==None):
                    root.trace=x
                    #print "X: data: ",x.data
            if (root.alpha>=root.beta):
                queue=[]
                #if(k==0):
                #    print "------------",root.trace.data
                return root.alpha
        return root.alpha


    elif (k%2==1):
        queue1=child_gen_sol(root,root.alpha,root.beta)
        while (len(queue1)>0):
            xx=queue1.pop(0)
            res2=gen_tree(xx,k+1)
            if(res2<root.beta):
                root.beta=res2
                for o in range(len(queue1)):
                    queue1[o].beta=res2
                if (root.parent==None):
                    root.trace=xx
            if (root.beta<=root.alpha):
                queue1=[]
                return root.beta
        return root.beta


def child_gen_musk(root,alpha,beta):
    #minimizer nodes being generated : default value is= +inf
    muskpos=root.data
    board_cur=[dfe[:] for dfe in root.board]
    #print board_cur
    queue=[]
    for i in range(len(muskpos)):

        if (muskpos[i][1]-1 >=0 and board_cur[muskpos[i][0]][muskpos[i][1]-1] ==2):
            da = [dfe[:] for dfe in muskpos]
            da.pop(i)
            da.insert(i,[muskpos[i][0],muskpos[i][1]-1])
            ga=[dfe[:] for dfe in root.gaps]
            ga.append([muskpos[i][0],muskpos[i][1]])
            boa=[dfe[:] for dfe in board_cur]
            boa[muskpos[i][0]][muskpos[i][1]-1]=1
            boa[muskpos[i][0]][muskpos[i][1]]=0
            x=node(alpha,beta,float('Inf'),da,[dfe[:] for dfe in muskpos],ga,[df[:] for df in boa],root,'min',None,[])
            root.children.append(x)
            queue.append(x)
            #print da," : ",boa

        if ((muskpos[i][0]+1) < len(board_cur) and board_cur[muskpos[i][0]+1][muskpos[i][1]] ==2):
            da=[dfe[:] for dfe in muskpos]
            da.pop(i)
            da.insert(i,[muskpos[i][0]+1,muskpos[i][1]])
            ga=[dfe[:] for dfe in root.gaps]
            ga.append([muskpos[i][0],muskpos[i][1]])
            boa=[dfe[:] for dfe in board_cur]
            boa[muskpos[i][0]+1][muskpos[i][1]]=1
            boa[muskpos[i][0]][muskpos[i][1]]=0
            x=node(alpha,beta,float('Inf'),da,[dfe[:] for dfe in muskpos],ga,[df[:] for df in boa],root,'min',None,[])
            root.children.append(x)
            queue.append(x)


        if ((muskpos[i][1]+1) < len(board_cur[i]) and board_cur[muskpos[i][0]][muskpos[i][1]+1] ==2):
            da=[dfe[:] for dfe in muskpos]
            da.pop(i)
            da.insert(i,[muskpos[i][0],muskpos[i][1]+1])
            ga=[dfe[:] for dfe in root.gaps]
            ga.append([muskpos[i][0],muskpos[i][1]])
            boa=[dfe[:] for dfe in board_cur]
            boa[muskpos[i][0]][muskpos[i][1]+1]=1
            boa[muskpos[i][0]][muskpos[i][1]]=0
            x=node(alpha,beta,float('Inf'),da,[dfe[:] for dfe in muskpos],ga,[df[:] for df in boa],root,'min',None,[])
            root.children.append(x)
            queue.append(x)

        if ((muskpos[i][0]-1) >= 0 and board_cur[muskpos[i][0]-1][muskpos[i][1]] ==2):
            da=[dfe[:] for dfe in muskpos]
            da.pop(i)
            da.insert(i,[muskpos[i][0]-1,muskpos[i][1]])
            ga=[dfe[:] for dfe in muskpos]
            ga.append([muskpos[i][0],muskpos[i][1]])
            boa=[dfe[:] for dfe in board_cur]
            boa[muskpos[i][0]-1][muskpos[i][1]]=1
            boa[muskpos[i][0]][muskpos[i][1]]=0
            x=node(alpha,beta,float('Inf'),da,[dfe[:] for dfe in muskpos],ga,[df[:] for df in boa],root,'min',None,[])
            root.children.append(x)
            queue.append(x)

    return queue

def child_gen_sol(root,alpha,beta):
    #minimizer nodes being generated : default value is= +inf
    gap_pos=root.gaps
    board_cur=[dfe[:] for dfe in root.board]
    queue=[]
    for i in range(len(gap_pos)):

        if ((gap_pos[i][1]-1) >=0 and board_cur[gap_pos[i][0]][gap_pos[i][1]-1] ==2):
            da = [dfe[:] for dfe in gap_pos]
            da.pop(i)
            da.insert(i,[gap_pos[i][0],gap_pos[i][1]-1])
            boa=[dfe[:] for dfe in board_cur]
            boa[gap_pos[i][0]][gap_pos[i][1]-1]=0
            boa[gap_pos[i][0]][gap_pos[i][1]]=2
            x=node(alpha,beta,-float('Inf'),[d[:]for d in root.data],[dfe[:] for dfe in root.camefrom],da,[df[:] for df in boa],root,'max',None,[])
            root.children.append(x)
            queue.append(x)

        if ((gap_pos[i][0]+1) < len(board_cur) and board_cur[gap_pos[i][0]+1][gap_pos[i][1]] ==2):
            da=[dfe[:] for dfe in gap_pos]
            da.pop(i)
            da.insert(i,[gap_pos[i][0]+1,gap_pos[i][1]])
            boa=[dfe[:] for dfe in board_cur]
            boa[gap_pos[i][0]+1][gap_pos[i][1]]=0
            boa[gap_pos[i][0]][gap_pos[i][1]]=2
            x=node(alpha,beta,-float('Inf'),[d[:] for d in root.data],[dfe[:] for dfe in root.camefrom],da,[df[:] for df in boa],root,'max',None,[])
            root.children.append(x)
            queue.append(x)

        if ((gap_pos[i][1]+1) < len(board_cur[0]) and board_cur[gap_pos[i][0]][gap_pos[i][1]+1] ==2):
            da=[dfe[:] for dfe in gap_pos]
            da.pop(i)
            da.insert(i,[gap_pos[i][0],gap_pos[i][1]+1])
            boa=[dfe[:] for dfe in board_cur]
            boa[gap_pos[i][0]][gap_pos[i][1]+1]=0
            boa[gap_pos[i][0]][gap_pos[i][1]]=2
            x=node(alpha,beta,-float('Inf'),[d[:] for d in root.data],[dfe[:] for dfe in root.camefrom],da,[df[:] for df in boa],root,'max',None,[])
            root.children.append(x)
            queue.append(x)

        if ((gap_pos[i][0]-1) >= 0 and board_cur[gap_pos[i][0]-1][gap_pos[i][1]] ==2):
            da=[dfe[:] for dfe in gap_pos]
            da.pop(i)
            da.insert(i,[gap_pos[i][0]-1,gap_pos[i][1]])
            boa=[dfe[:] for dfe in board_cur]
            boa[gap_pos[i][0]-1][gap_pos[i][1]]=0
            boa[gap_pos[i][0]][gap_pos[i][1]]=2
            x=node(alpha,beta,-float('Inf'),[d[:] for d in root.data],[dfe[:] for dfe in root.camefrom],da,[df[:] for df in boa],root,'max',None,[])
            root.children.append(x)
            queue.append(x)

    return queue
