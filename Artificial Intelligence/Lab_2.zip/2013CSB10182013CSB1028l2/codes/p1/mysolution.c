#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <errno.h>

#define CAPACITY 10000//Increase capacity not included

void calc_param(int *T, int *N, int *B, int *C, FILE *file) {
	fscanf(file, "%d", T);
	fscanf(file, "%d", N);
	fscanf(file, "%d", B);
	fscanf(file, "%d", C);
}

struct bid {
	int size;
	int capacity;
	int nBlocks;
	int *blocks;
	int companyID;
	int bidVal;
	int bidID;
	int ratio;
	double prob;
	struct bid *next;
};

void bid_double_capacity_if_full(struct bid *new_bid) {
  if (new_bid->size >= new_bid->capacity) {
    new_bid->capacity += 10;
    new_bid->blocks = realloc(new_bid->blocks, sizeof(int) * new_bid->capacity);
  }
}

struct bid *readFile(FILE *file) {
	struct bid *start=NULL;
	struct bid *current;
	int count=0;
	while(1) {
		int compID=-1;
		int noOfBids;
		fscanf(file,"%d",&compID);
		if(compID==-1)
			break;
		fscanf(file,"%d",&noOfBids);
		int itr;
		if(noOfBids==0)
			continue;
		struct bid *new_bid;
		for(itr=0;itr<noOfBids;itr++) {
			new_bid->size=0;
			new_bid->capacity=CAPACITY;
			new_bid=(struct bid *)malloc(sizeof(struct bid));
			fscanf(file,"%d",&new_bid->companyID);
			fscanf(file,"%d",&new_bid->nBlocks);
			fscanf(file,"%d",&new_bid->bidVal);
			new_bid->ratio = (new_bid->bidVal)/((new_bid->nBlocks)*(new_bid->nBlocks));
			new_bid->bidID = count++;
			int i;
			new_bid->blocks=(int *)malloc(CAPACITY);
			for(i=0;i<new_bid->nBlocks;i++) {
				// bid_double_capacity_if_full(new_bid);
				fscanf(file,"%d",&(new_bid->blocks[i]));
				new_bid->size++;
			}
			//linking the bids
			if(start==NULL) {
			start=new_bid;
			current=new_bid;
			}
			else {
			current->next=new_bid;
			current=new_bid;
			}
			current->next=NULL;
		}
	}
	return start;
}

// Decreasing sort by bid value
struct bid* SortedMerge(struct bid* a, struct bid* b) {
	struct bid* result = NULL;
	if (a == NULL)
		return(b);
	else if (b==NULL)
		return(a);
	if (a->ratio >= b->ratio) {
		result = a;
		result->next = SortedMerge(a->next, b);
	}
	else {
		result = b;
		result->next = SortedMerge(a, b->next);
	}
	return(result);
}

void FrontBackSplit(struct bid* source, struct bid** frontRef, struct bid** backRef) {
	struct bid* fast;
	struct bid* slow;
	if (source==NULL || source->next==NULL) {
		*frontRef = source;
		*backRef = NULL;
	}
	else {
		slow = source;
		fast = source->next;
		while (fast != NULL) {
			fast = fast->next;
			if (fast != NULL) {
				slow = slow->next;
				fast = fast->next;
			}
		}
		*frontRef = source;
		*backRef = slow->next;
		slow->next = NULL;
	}
}

void MergeSort(struct bid** headRef) {
	struct bid* head = *headRef;
	struct bid* a;
	struct bid* b;
	if ((head == NULL) || (head->next == NULL)) {
		return;
	}
	FrontBackSplit(head, &a, &b); 
	MergeSort(&a);
	MergeSort(&b);
	*headRef = SortedMerge(a, b);
}

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

int main(int argc, char *argv[]) {
	clock_t start_t, end_t;
	int time_taken;

	long int restart = 10000;
	long int r=0;
	FILE *file;
	file = fopen(argv[1],"r");
	FILE *output;
	output = fopen(argv[2],"a");
	int T, N, B, C, tVal, cVal, nVal, timeVal;
	calc_param(&T, &N, &B, &C, file);
	tVal = B;
	cVal = C;
	nVal = N;
	timeVal = T;
	struct bid *start=readFile(file);
	time_t t;
	srand((unsigned) time(&t));
	int final_value=0;
	int *finalBids=(int *)calloc(tVal,sizeof(int));
	int final_index=0;
	MergeSort(&start);
	struct bid* temp_bid = start;
	int sumOfValues = 0;
	while(temp_bid) {
		sumOfValues = temp_bid->ratio+sumOfValues;
		temp_bid=temp_bid->next; 
	}
	temp_bid = start;
	while(temp_bid) {
		temp_bid->prob = (double)temp_bid->ratio/(double)sumOfValues;
		temp_bid=temp_bid->next; 
	}
	long int num=0;
	start_t = clock();
	while(num<restart) {
		num++;
		int initial_bid = rand()%tVal;
		
		int *blocksCheck;
		blocksCheck=(int *)calloc(nVal,sizeof(int));
		int *companyCheck;
		companyCheck=(int *)calloc(cVal,sizeof(int));
		
		struct bid *current;
		struct bid *temp;
		int value=0;
		int *bidsChosen;
		bidsChosen=(int *)calloc(B,sizeof(int));
		int bidChosenIndex=0;
		temp=start;
		while(temp) {
			if(temp->bidID==initial_bid) {
				bidsChosen[bidChosenIndex++]=temp->bidID;
				value = temp->bidVal;
				companyCheck[temp->companyID]++;
				int i;
				for(i=0;i<(temp->nBlocks);i++) {
					blocksCheck[temp->blocks[i]]++;
				}
			}
			temp=temp->next;
		}
		int itr=10000;
		while(itr--) {
			int rand_init_bid = rand()%tVal;
			temp=start;
			while(temp) {
				if(temp->bidID == rand_init_bid) {
					int number = rand()%100000;
					double probability = (double)number/(double)100000;
					if(companyCheck[temp->companyID]==0 && probability>(temp->prob)) {
						int flag=0;
						int i;
						for(i=0;i<(temp->nBlocks);i++) {
							if(blocksCheck[temp->blocks[i]]>0)
								flag=1;
						}
						if(flag==0) {
							value += temp->bidVal;
							bidsChosen[bidChosenIndex++]=temp->bidID;
							for(i=0;i<(temp->nBlocks);i++)
								blocksCheck[temp->blocks[i]]++;
						}
					}
				}
				temp=temp->next;
			}
		}
		// printf("%d\n", nVal);
		// int k=0;
		// for(k=0;k<nVal;k++) {
			// printf("ok");
			// printf("%d ", blocksCheck[k]);
		// }
		// printf("\n");

		qsort(bidsChosen, bidChosenIndex, sizeof(int), cmpfunc);
		int j;
		if(value>final_value) {
			r=num-1;
			final_value=value;
			final_index=bidChosenIndex;
			for(j=0;j<bidChosenIndex;j++) {
				finalBids[j]=bidsChosen[j];
			}
		}
	}
	while(1) {
		end_t = clock();
		time_taken = ((int) (end_t - start_t)) / CLOCKS_PER_SEC;
		if(timeVal*60<time_taken)
			break;
	}
	int i;
	fprintf(output,"%d ",final_value);
	qsort(finalBids, final_index, sizeof(int), cmpfunc);
	for(i=0;i<final_index;i++)
		fprintf(output,"%d ",finalBids[i]);
	fprintf(output,"\n");
	return 0;
}