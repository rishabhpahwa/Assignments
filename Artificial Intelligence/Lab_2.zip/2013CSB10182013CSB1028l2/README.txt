TEAM MEMBERS:
Milind Aggarwal (2013CSB1018)
Rishabh Pahwa (2013CSB1028)

Problem P1
==========
Steps to Execute the script:
----------------------------

1) To compile the c code run: gcc code.c -o code
2) To obtain the output run:  ./code {input.txt} output.txt

Note: Here {input.txt} corresponds to the input file.


Problem P2
==========
Note:	The file controller2.py has been renamed to 2013CSB10182013CSB1028.py
		corresponding to the roll numbers of the group members.
		
		To evaluate the code, please run the automated script checker as mentioned
		in the problem PDF.
