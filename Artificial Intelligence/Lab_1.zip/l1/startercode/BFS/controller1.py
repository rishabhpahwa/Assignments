# This function takes board as an input
# returns three lists as described in README file
# In board, following convention is followed
#         1 -> musketeer
#         2 -> soldier
#         0 -> empty location
#         3 -> Soldier With Diamond (Goal State)


def singleAgentSearch(board):
	exploredNodes = []
	searchQueue  = []
	shortestPath = []
	exploredNodes1=[[],[],[]]
	searchQueue1=[[],[],[]]
	ShortestPath1=[]
	row=[]
	column=[]
	res1=[]
	ex=[]
	for i in range(len(board)):
		for j in range(len(board[i])):
			if(board[i][j]==1):
				row.append(i)
				column.append(j)
	c=[]
	paths=[]
        for i in range(len(row)):
            j=row[i]
            k=column[i]
            searchQueue1[i].append([j,k])
            
            visited=[[0 for xx in xrange(len(board[0]))] for xxx in xrange(len(board))]
            cost=[[0 for xx in xrange(len(board[0]))] for xxx in xrange(len(board))]
            res=[]
            
            while(len(searchQueue1[i])>0):
                cur=searchQueue1[i].pop(0)
                #print cur
                visited[cur[0]][cur[1]]=1
                
                if (board[cur[0]][cur[1]]==3):
                    res.append(searchQueue1[i][:])
                    exploredNodes1[i].append(cur)
                    break;
                
                if ((cur[1]-1)>=0 and (board[cur[0]][cur[1]-1]==2 or board[cur[0]][cur[1]-1]==3) and visited[cur[0]][cur[1]-1]==0):
                    searchQueue1[i].append([cur[0],cur[1]-1])
                    visited[cur[0]][cur[1]-1]=1
                    cost[cur[0]][cur[1]-1]=cost[cur[0]][cur[1]]+1
                
                if ((cur[0]+1)<len(board) and (board[cur[0]+1][cur[1]]==2 or board[cur[0]+1][cur[1]]==3) and visited[cur[0]+1][cur[1]]==0):
                    searchQueue1[i].append([cur[0]+1,cur[1]])
                    visited[cur[0]+1][cur[1]]=1
                    cost[cur[0]+1][cur[1]]=cost[cur[0]][cur[1]]+1
                
                if ((cur[1]+1)<len(board[cur[0]]) and (board[cur[0]][cur[1]+1]==2 or board[cur[0]][cur[1]+1]==3) and visited[cur[0]][cur[1]+1]==0):
                    searchQueue1[i].append([cur[0],cur[1]+1])
                    visited[cur[0]][cur[1]+1]=1
                    cost[cur[0]][cur[1]+1]=cost[cur[0]][cur[1]]+1
                
                if ((cur[0]-1)>=0 and (board[cur[0]-1][cur[1]]==2 or board[cur[0]-1][cur[1]]==3) and visited[cur[0]-1][cur[1]]==0):
                    searchQueue1[i].append([cur[0]-1,cur[1]])
                    visited[cur[0]-1][cur[1]]=1
                    cost[cur[0]-1][cur[1]]=cost[cur[0]][cur[1]]+1
                
                exploredNodes1[i].append(cur)
                res.append(searchQueue1[i][:])
                #print res,"\n"
            res1.append(res)
            ex.append(exploredNodes1[i][:])
            #print ex[i]        
            c.append(cost[cur[0]][cur[1]])
            x=cur[0]
            y=cur[1]
            path=[]
            path.append([x,y])
            while (x!=j or y!=k):
                if ((x-1)>=0 and (cost[x-1][y]==cost[x][y]-1)):
                    x=x-1
                    path.append([x,y])
                elif ((y+1)<len(board[x]) and (cost[x][y+1]==cost[x][y]-1)):
                    y=y+1
                    path.append([x,y])
                elif ((x+1)<len(board) and (cost[x+1][y]==cost[x][y]-1)):
                    x=x+1
                    path.append([x,y])
                elif ((y-1)>=0 and (cost[x][y-1]==cost[x][y]-1)):
                    y=y-1
                    path.append([x,y])
            paths.append(path[::-1])
            #print paths[i]        
                    
	# YOUR CODE HERE #
	#print res1[0]
	index=0
	min=c[0]
	for k in range(len(c)):
	    if (c[k]<min):
	        min=c[k]
	        index=k
	exploredNodes=ex[index][:]
	searchQueue=res1[index][:]
	shortestPath=paths[index][:]
	return (exploredNodes,searchQueue,shortestPath)