import view
try:
            view.main()
except:
            print('Invalid List Format')
            view.terminate()
