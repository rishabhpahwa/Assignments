# This function takes board as an input
# returns three lists as described in README file
# In board, following convention is followed
#         1 -> musketeer
#         2 -> soldier
#         0 -> empty location
#         3 -> Soldier With Diamond (Goal State)

import math
def singleAgentSearch(board):
	exploredNodes = []
	searchQueue  = []
	shortestPath = []
        exploredNodes1=[[],[],[]]
	searchQueue1=[[],[],[]]
	heuristicsQueue=[[],[],[]]
	row=[]
	column=[]
	res1=[]
	ex=[]
	diamond=[]
	for i in range(len(board)):
		for j in range(len(board[i])):
			if(board[i][j]==1):
				row.append(i)
				column.append(j)
			if(board[i][j]==3):
			    diamond.append(i)
			    diamond.append(j)
	heuristics1=[]
	for i in range(len(board)):
	    h=[]
	    for j in range(len(board[i])):
	        h.append(math.sqrt((i-diamond[0])*(i-diamond[0]) + (j-diamond[1])*(j-diamond[1])))
	    heuristics1.append(h[:])
	#print heuristics
	
	c=[]
	paths=[]
        for i in range(len(row)):
            j=row[i]
            k=column[i]
            searchQueue1[i].append([j,k])
            #heuristics=heuristics1[:][:]
            heuristics = [dfe[:] for dfe in heuristics1]
            #print heuristics
            heuristicsQueue[i].append(heuristics[j][k])
            
            visited=[[0 for xx in xrange(len(board[0]))] for xxx in xrange(len(board))]
            cost=[[0 for xx in xrange(len(board[0]))] for xxx in xrange(len(board))]
            res=[]
            
            while(len(searchQueue1[i])>0):
                cur=searchQueue1[i].pop(0)
                heuristicsQueue[i].pop(0)
                #print cur
                visited[cur[0]][cur[1]]=1
                
                if (board[cur[0]][cur[1]]==3):
                    res.append(searchQueue1[i][:])
                    exploredNodes1[i].append(cur)
                    break;
                
                if ((cur[1]-1)>=0 and (board[cur[0]][cur[1]-1]==2 or board[cur[0]][cur[1]-1]==3) and visited[cur[0]][cur[1]-1]==0):
                    searchQueue1[i].append([cur[0],cur[1]-1])
                    cost[cur[0]][cur[1]-1]=cost[cur[0]][cur[1]]+1
                    heuristics[cur[0]][cur[1]-1]=heuristics[cur[0]][cur[1]-1]+cost[cur[0]][cur[1]-1]
                    heuristicsQueue[i].append(heuristics[cur[0]][cur[1]-1])
                    visited[cur[0]][cur[1]-1]=1
                
                if ((cur[0]+1)<len(board) and (board[cur[0]+1][cur[1]]==2 or board[cur[0]+1][cur[1]]==3) and visited[cur[0]+1][cur[1]]==0):
                    searchQueue1[i].append([cur[0]+1,cur[1]])
                    cost[cur[0]+1][cur[1]]=cost[cur[0]][cur[1]]+1
                    heuristics[cur[0]+1][cur[1]]=heuristics[cur[0]+1][cur[1]]+cost[cur[0]+1][cur[1]]
                    heuristicsQueue[i].append(heuristics[cur[0]+1][cur[1]])
                    visited[cur[0]+1][cur[1]]=1
                
                if ((cur[1]+1)<len(board[cur[0]]) and (board[cur[0]][cur[1]+1]==2 or board[cur[0]][cur[1]+1]==3) and visited[cur[0]][cur[1]+1]==0):
                    searchQueue1[i].append([cur[0],cur[1]+1])
                    cost[cur[0]][cur[1]+1]=cost[cur[0]][cur[1]]+1
                    heuristics[cur[0]][cur[1]+1]=heuristics[cur[0]][cur[1]+1]+cost[cur[0]][cur[1]+1]
                    heuristicsQueue[i].append(heuristics[cur[0]][cur[1]+1])
                    visited[cur[0]][cur[1]+1]=1
                    
                if ((cur[0]-1)>=0 and (board[cur[0]-1][cur[1]]==2 or board[cur[0]-1][cur[1]]==3) and visited[cur[0]-1][cur[1]]==0):
                    searchQueue1[i].append([cur[0]-1,cur[1]])
                    cost[cur[0]-1][cur[1]]=cost[cur[0]][cur[1]]+1
                    heuristics[cur[0]-1][cur[1]]=heuristics[cur[0]-1][cur[1]]+cost[cur[0]-1][cur[1]]
                    heuristicsQueue[i].append(heuristics[cur[0]-1][cur[1]])
                    visited[cur[0]-1][cur[1]]=1
                    
                searchQueue1[i]=[x for (y,x) in sorted(zip(heuristicsQueue[i],searchQueue1[i][:]), key=lambda pair: pair[0])]
                heuristicsQueue[i].sort()
                #print searchQueue1[i]," : ", heuristicsQueue[i]
                exploredNodes1[i].append(cur)
                res.append(searchQueue1[i][:])
                #print res,"\n"
            res1.append(res)
            ex.append(exploredNodes1[i][:])
            #print cost[cur[0]][cur[1]]        
            c.append(cost[cur[0]][cur[1]])
            x=cur[0]
            y=cur[1]
            path=[]
            path.append([x,y])
            while (x!=j or y!=k):
                if ((x-1)>=0 and (cost[x-1][y]==cost[x][y]-1)):
                    x=x-1
                    path.append([x,y])
                elif ((y+1)<len(board[x]) and (cost[x][y+1]==cost[x][y]-1)):
                    y=y+1
                    path.append([x,y])
                elif ((x+1)<len(board) and (cost[x+1][y]==cost[x][y]-1)):
                    x=x+1
                    path.append([x,y])
                elif ((y-1)>=0 and (cost[x][y-1]==cost[x][y]-1)):
                    y=y-1
                    path.append([x,y])
            paths.append(path[::-1])
            #print paths[i]        
                    
	# YOUR CODE HERE #
	#print res1[0]
	index=0
	min=c[0]
	for k in range(len(c)):
	    if (c[k]<min):
	        min=c[k]
	        index=k
	exploredNodes=ex[index][:]
	searchQueue=res1[index][:]
	shortestPath=paths[index][:]
	return (exploredNodes,searchQueue,shortestPath)
#b=[[0, 2, 2, 2, 1],[2, 2, 2, 0, 2],[2, 1, 0, 3, 2],[2, 2, 0, 2, 2],[1, 2, 2, 2, 0]]
#x=singleAgentSearch(b[:][:])
